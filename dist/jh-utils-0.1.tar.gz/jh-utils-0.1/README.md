# My python lib

Python lib with utils to help me in day by day tasks